    <div class="bg-dark">
        <div class="container">
            <div class="row p-3">
                <div class="col-12 text-center text-white">
                    <span>
                        Jiroload | Copyright © {{ date('Y') }}.
                    </span>
                </div>
            </div>
        </div>
    </div>
