

<?php $__env->startSection('content'); ?>
    <div class="container bg-white p-3">
        <div class="row">
            <div class="col-12">
                <div class="row">
                    <div class="col-6">
                        <h3>Tags SEO</h3>
                    </div>
                    <div class="col-6 text-end">
                        <button type="button" class="btn btn-primary add-seo-row">Add +</button>
                    </div>
                </div>
                <hr class="m-0 mt-3">
                <form action="<?php echo e(url('/admin/process/seo')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <?php
                            $i = 0;
                        ?>
                        <?php $__currentLoopData = $seo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($item->status == '1'): ?>
                                <div class="row mt-3" id="row-<?php echo e($i); ?>">
                                    <div class="col-11">
                                        <input type="hidden" name="seo[<?php echo e($i); ?>][id]"
                                            value="<?php echo e($item->id); ?>">
                                        <input type="hidden" name="seo[<?php echo e($i); ?>][action]" value="update">
                                        <input type="text" name="seo[<?php echo e($i); ?>][value]" class="form-control"
                                            value="<?php echo e($item->value); ?>">
                                    </div>
                                    <div class="col-1 text-center">
                                        <button type="button" onclick="del('<?php echo e($item->id); ?>')"
                                            class="btn btn-danger">X</button>
                                    </div>
                                </div>
                                <?php
                                    $i++;
                                ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="row mt-3">
                        <div class="col-12">
                            <button type="submit" class="btn btn-success">บันทึก</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>


    <script>
        let number = '<?php echo e($i); ?>';
        $('.add-seo-row').on('click', function() {
            let html = '';
            html += ` <div class="row mt-3" id="row-${number}">
                            <div class="col-11">
                                <input type="hidden" name="seo[${number}][action]" value="add">
                                <input type="text" name="seo[${number}][value]" class="form-control">
                            </div>
                            <div class="col-1 text-center">
                                <button type="button" onclick="$('#row-${number}').remove();" class="btn btn-danger">X</button>
                            </div>
                        </div>`;
            $('.form-group').append(html);
            number++;
        });

        function del(id) {
            $('#row-' + id).remove();
            $.ajax({
                url: '<?php echo e(url('/admin/process/seo')); ?>',
                type: 'post',
                data: {
                    id: id,
                    action: 'delete',
                    _token: '<?php echo e(csrf_token()); ?>'
                },
                success: function(response) {
                    console.log(response);
                    window.location.reload();
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\portal\Fullstack\loader\resources\views/admin/seo.blade.php ENDPATH**/ ?>