

<?php $__env->startSection('content'); ?>
    <div class="container mt-3 p-3 bg-white">
        <div class="row">
            <div class="col-12">
                <h3>โพสต์</h3>
                <hr class="m-0">
            </div>
        </div>
        <div class="row mt-3">
            <div class="col-12">
                <form action="<?php echo e(url('/admin/new/post')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="post_id" value="<?php if($data && is_object($data)): ?> <?php echo e($data->id); ?> <?php endif; ?>">
                    <input type="hidden" name="process" value="<?php echo e($process); ?>">
                    <input type="hidden" name="post_status"
                        value="<?php if($data && is_object($data)): ?> <?php echo e($data->post_status); ?> <?php endif; ?>">

                    <div class="row">
                        <div class="col-12">
                            <label for="category">หมวดหมู่</label>
                            <select class="form-select" name="post_catergory" id="category" required
                                value="<?php if($data && is_object($data)): ?> <?php echo e($data->post_catergory); ?> <?php endif; ?>">
                                <option value="">เลือกหมวดหมู่</option>
                                <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"
                                        <?php if($data && is_object($data)): ?> <?php if($item->id == $data->post_catergory): ?> selected <?php endif; ?>
                                        <?php endif; ?>><?php echo e($item->category_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="row mt-3">
                        <div class="col-12">
                            <div class="form-floating">
                                <input type="text" class="form-control" id="post_name" name="post_name" required
                                    <?php if($data && is_object($data)): ?> value="<?php echo e($data->post_name); ?>"<?php endif; ?>>
                                <label for="post_name">ชื่อโพสต์</label>
                            </div>
                        </div>
                    </div>

                    <div class="row mt-3">
                        <div class="col-12">
                            <div class="form-floating">
                                <input type="text" class="form-control" id="post_image" name="post_image" required
                                    <?php if($data && is_object($data)): ?> value="<?php echo e($data->post_image); ?>"<?php endif; ?>>
                                <label for="post_image">URL รูปภาพหน้าปก</label>
                            </div>
                        </div>
                    </div>

                    <div class="row mt-3">
                        <div class="col-12">
                            <div class="form-floating">
                                <input type="text" class="form-control" id="link_loader" name="link_loader" required
                                    <?php if($data && is_object($data)): ?> value="<?php echo e($data->link_load); ?>" <?php endif; ?>>
                                <label for="link_loader">Link Download</label>
                            </div>
                        </div>
                    </div>


                    <div class="row mt-3">
                        <div class="col-12 ">
                            <textarea name="post_description" class="post_description" rows="30" required>
                                <?php if($data && is_object($data)): ?>
                                    <?php echo e($data->post_description); ?>

                                <?php endif; ?>
                            </textarea>
                        </div>
                    </div>


                    <div class="row mt-3">
                        <div class="col-12">
                            <label for="description_seo">รายละเอียดเพิ่มเติม SEO</label>
                            <textarea name="description_seo" class="form-control" id="description_seo" cols="30" rows="10"><?php if($data && is_object($data)): ?><?php echo e($data->description_seo); ?><?php endif; ?></textarea>
                        </div>
                    </div>

                    <div class="row mt-3">
                        <div class="col-12">
                            <button class="btn btn-success" type="submit">Save</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>


    <script>
        tinymce.init({
            selector: '.post_description',
            plugins: 'ai tinycomments mentions anchor autolink charmap codesample emoticons image link lists media searchreplace table visualblocks wordcount checklist mediaembed casechange export formatpainter pageembed permanentpen footnotes advtemplate advtable advcode editimage tableofcontents mergetags powerpaste tinymcespellchecker autocorrect a11ychecker typography inlinecss',
            toolbar: 'undo redo | blocks fontfamily fontsize | bold italic underline strikethrough | link image media table mergetags | align lineheight | tinycomments | checklist numlist bullist indent outdent | emoticons charmap | removeformat',
            tinycomments_mode: 'embedded',
            tinycomments_author: 'Author name',
            images_upload_url: 'postAcceptor.php',
            images_upload_base_path: '/some/basepath',
            mergetags_list: [{
                    value: 'First.Name',
                    title: 'First Name'
                },
                {
                    value: 'Email',
                    title: 'Email'
                },
            ],
            ai_request: (request, respondWith) => respondWith.string(() => Promise.reject(
                "See docs to implement AI Assistant")),
        });

        $(function() {
            $('input')
                .on('change', function(event) {
                    var $element = $(event.target);
                    var $container = $element.closest('.example');

                    if (!$element.data('tagsinput')) return;

                    var val = $element.val();
                    if (val === null) val = 'null';
                    var items = $element.tagsinput('items');

                    $('code', $('pre.val', $container)).html(
                        $.isArray(val) ?
                        JSON.stringify(val) :
                        '"' + val.replace('"', '\\"') + '"'
                    );
                    $('code', $('pre.items', $container)).html(
                        JSON.stringify($element.tagsinput('items'))
                    );
                })
                .trigger('change');
        });
    </script>


    <style>
        .bootstrap-tagsinput .tag {
            margin-right: 2px;
            color: white !important;
            background-color: #0d6efd;
            padding: 0.2rem;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\portal\Fullstack\loader\resources\views/admin/form_post.blade.php ENDPATH**/ ?>