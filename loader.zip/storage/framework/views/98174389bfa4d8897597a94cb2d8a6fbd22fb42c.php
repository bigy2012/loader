

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row d-flex justify-content-center">
            <div class="col-8  bg-white p-3" style="border-radius: 10px">
                <div class="row">
                    <div class="col-12">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item">หน้าแรก</li>
                                <li class="breadcrumb-item"><?php echo e($category->category_name); ?></li>
                                <li class="breadcrumb-item"><?php echo e($data->post_name); ?></li>
                            </ol>
                        </nav>
                        
                    </div>
                </div>

                <div class="row mt-3">
                    <div class="col-12" style="font-weight: bold">
                        <h1><?php echo e($data->post_name); ?></h1>
                    </div>
                </div>

                <div class="row">
                    <div class="col-12" style="font-weight: bold">
                        <label class="text-secondary"><?php echo e($created_date); ?></label>
                    </div>
                </div>

                <div class="row mt-3">
                    <div class="col-12" style="font-weight: bold" style="width: 100%; height: 300px;">
                        <?php echo html_entity_decode($data->post_description); ?>

                    </div>
                </div>

                <div class="row mt-3">
                    <div class="col-12 text-center">
                        <a class="btn" href="<?php echo e($data->link_load); ?>"
                            target="_blank"
                            style="background: #34b703; color: white; border-radius: 25px; width: 200px; padding: 10px">ดาวน์โหลด</a>
                    </div>
                </div>
            </div>
        </div>
    </div>


    


    <style type="text/css">

        .widget-content:hover {
            transform: scale(1.1);
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\portal\Fullstack\loader\resources\views/details.blade.php ENDPATH**/ ?>