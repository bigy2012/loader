

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row p-0">
            <div class="col-3 mx-1 bg-white py-3" style="border-radius: 5px;">
                <div class="row">
                    <div class="col-12 text-center">
                        <label for="" style="color: #6c757d">จำนวนการเข้าชมเว็บไซต์/คน</label>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 text-center">
                        <h4><?php echo e($visitCount); ?></h4>
                    </div>
                </div>
            </div>
            <div class="col-3 mx-1 bg-white py-3" style="border-radius: 5px;">
                <div class="row">
                    <div class="col-12 text-center">
                        <label for="" style="color: #6c757d">จำนวนโพสต์</label>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 text-center">
                        <h4><?php echo e($PostCount); ?></h4>
                    </div>
                </div>
            </div>
            <div class="col-3 mx-1 bg-white py-3" style="border-radius: 5px;">
                <div class="row">
                    <div class="col-12 text-center">
                        <label for="" style="color: #6c757d">จำนวนหมวดหมู่</label>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 text-center">
                        <h4><?php echo e($CategoryCount); ?></h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\portal\Fullstack\loader\resources\views/admin/home.blade.php ENDPATH**/ ?>