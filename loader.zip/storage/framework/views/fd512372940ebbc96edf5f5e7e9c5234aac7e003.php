

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row d-flex justify-content-center">
            <div class="col-10  bg-white p-3" style="border-radius: 10px">
                <div class="row">
                    <div class="col-12 text-center" style="font-weight: bold">
                        <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($category_id == $item->id): ?>
                                <h1><?php echo e($item->category_name); ?> | Jiroload</h1>
                            <?php break; ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="row mt-1">
                <div class="col-12" style="font-weight: bold">
                    <nav class="navbar navbar-expand-sm navbar-light bg-light">
                        <div class="container-fluid">
                            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(url('/')); ?>">All</a>
                                </li>
                                <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="nav-item">
                                        <a class="nav-link <?php if($category_id == $item->id): ?> active <?php endif; ?>"
                                            href="<?php echo e(url('/category/' . $item->id)); ?>"><?php echo e($item->category_name); ?></a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </nav>
                </div>
            </div>
            <div class="row">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($item->post_status == '1'): ?>
                        <div class="col-3 widget-content">
                            <a href="<?php echo e(url('/detail/' . $item->post_name . '/' . $item->id)); ?>"
                                style="text-decoration: none;">
                                <div class="card my-3">
                                    <img src="<?php echo e($item->post_image); ?>" class="card-img-top" alt="">
                                    <div class="card-body">
                                        <h5 class="card-title"><?php echo e($item->post_name); ?></h5>
                                    </div>
                                </div>
                            </a>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="d-flex">
                <?php echo $data->links(); ?>

            </div>
        </div>
    </div>
</div>



<style>
    .widget-content:hover {
        transform: scale(1.1);
    }

    .card:hover {
        color: blue;
    }
</style>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\portal\Fullstack\loader\resources\views/category.blade.php ENDPATH**/ ?>