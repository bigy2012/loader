

<?php $__env->startSection('content'); ?>
    <div class="container bg-white p-3">
        <div class="row">
            <div class="col-12">
                <div class="row">
                    <div class="col-6">
                        <h3>All Posts</h3>
                    </div>
                    <div class="col-6 text-end">
                        <a href="<?php echo e(url('/admin/new/post/0/add')); ?>" class="btn btn-success">New Post</a>
                    </div>
                </div>
                <table class="table table-light">
                    <thead>
                        <tr>
                            <th style="width: 10%;">ลำดับ</th>
                            <th style="width: 10%;">รูป</th>
                            <th style="width: 50%;">ชื่อ</th>
                            <th style="width: 20%;">หมวดหมู่</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $i = 1;
                        ?>
                        <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($data->post_status == '1'): ?>
                                <tr>
                                    <td><?php echo e($i); ?></td>
                                    <td>
                                        <img src="<?php echo e($data->post_image); ?>" width="50px" height="50px" alt="">
                                    </td>
                                    <td><?php echo e($data->post_name); ?></td>
                                    <td>
                                        <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($data->post_catergory == $item->id): ?>
                                                <?php echo e($item->category_name); ?>

                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td>
                                        <a class="btn btn-warning"
                                            href="<?php echo e(url('/admin/new/post/' . $data->id . '/' . 'edit')); ?>">แก้ไข</a>
                                        <button onclick="del('<?php echo e($data->id); ?>')" class="btn btn-danger">ลบ</button>
                                    </td>
                                </tr>

                                <?php
                                    $i++;
                                ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <div class="d-flex">
                    <?php echo $post->links(); ?>

                </div>
            </div>
        </div>
    </div>


    <script>
        function del(id) {

            // Swal.fire({
            //     title: "The Internet?",
            //     text: "That thing is still around?",
            //     icon: "question",
            //     success: function(){}
            // });

            $.ajax({
                url: "<?php echo e(url('/admin/new/post')); ?>",
                method: "POST",
                data: {
                    _token: '<?php echo e(csrf_token()); ?>',
                    process: 'delete',
                    post_id: id
                },
                success: function(result) {
                    console.log(result);
                    // window.location.reload();
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\portal\Fullstack\loader\resources\views/admin/post.blade.php ENDPATH**/ ?>